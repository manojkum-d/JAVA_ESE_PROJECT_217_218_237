package com.dailycodework.lakesidehotel.exception;



public class InternalServerException extends RuntimeException {
    public InternalServerException(String message) {
        super(message);
    }
}

